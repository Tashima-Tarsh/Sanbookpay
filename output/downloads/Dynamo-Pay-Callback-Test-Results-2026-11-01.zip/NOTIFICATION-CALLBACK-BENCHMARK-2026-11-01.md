# Notification callback acceptance benchmark

Measured: 2026-11-01T06:43:09.157Z
Source: 8186e32b70bd4aa90318a490b90d89a373655a9a

50 sequential successes and one automatic-retry scenario. Isolated SQLite WAL, HTTP loopback, synthetic signed receiving alerts. No hosted/customer financial data used.

| Metric | p50 (ms) | p95 (ms) | max (ms) |
|---|---:|---:|---:|
| createMs | 11.28 | 12.4 | 22.17 |
| checkoutAndQrMs | 13.7 | 24.74 | 34.42 |
| alertToIngressAckMs | 8.2 | 13.54 | 35.38 |
| alertToCallbackReceivedMs | 8.36 | 13.68 | 35.61 |
| alertToWalletCommittedMs | 9.65 | 14.86 | 36.88 |
| createToWalletCommittedMs | 35.59 | 51.12 | 70.63 |

Automatic retry: 6586.39 ms to wallet credit; 2 callback attempts. First response was synthetic HTTP 503. No retry schedule was manually accelerated.

All signature, Paid/inquiry, ledger/outbox, notification duplicate, consumer duplicate and stable-retry identity assertions passed.

- No real bank transfer, receiving phone, Android app, Gmail consent or bank alert timing
- Not hosted Render/PostgreSQL latency, cold start, concurrent load, owner verification or live settlement acceptance
- Sequential warm-path samples; synthetic notification success is not bank verification
